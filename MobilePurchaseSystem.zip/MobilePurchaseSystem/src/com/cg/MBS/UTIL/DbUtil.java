package com.cg.MBS.UTIL;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DbUtil
{
	static Connection conn = null; 
	
	public static Connection getConnection()
	{
		FileInputStream fileRead;
		
		try
		{
			fileRead = new FileInputStream("oracle.properties");
			
			Properties pros = new Properties();
			pros.load(fileRead);
			
			String driver = pros.getProperty("oracle.driver");
			String url = pros.getProperty("oracle.url");
			String uname = pros.getProperty("oracle.username");
			String upass = pros.getProperty("oracle.password");
			
			Class.forName(driver);
			conn = DriverManager.getConnection(url,uname,upass);
			System.out.println("Connection established..........");
		} 
		
		catch (ClassNotFoundException | IOException | SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			System.out.println("connection not established.......");
			
		}
		return conn;
	}
}
