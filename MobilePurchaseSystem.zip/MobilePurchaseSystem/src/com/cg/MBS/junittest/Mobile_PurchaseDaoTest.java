package com.cg.MBS.junittest;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.MBS.DAO.Mobile_PurchaseDaoImpl;
import com.cg.MBS.dto.Mobiles;
import com.cg.MBS.dto.PurchaseDetails;
import com.cg.MBS.exception.Mobile_PurchaseException;
import com.cg.MBS.service.Mobile_PurchaseImpl;

public class Mobile_PurchaseDaoTest {

	Connection conn = null;
	PreparedStatement pstm=null;
	Mobiles mob = null;
	Mobile_PurchaseDaoImpl mobDao = null;
	PurchaseDetails PD = null;
	
	@Before
	public void callBefore(){
		mob = new Mobiles();
		mob.setMobileId(1004);
		mob.setName("iphone");
		mob.setPrice(120000);
		mob.setQuantity(12);
		
		mobDao = new Mobile_PurchaseDaoImpl();	
	}
	
	@Test
	public void TestCase() throws Mobile_PurchaseException{
		
		assertEquals(0,mobDao.addMobile(mob));
	}
	
	@After
	public void test() {
		
	}

}
