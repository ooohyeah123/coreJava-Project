package com.cg.MBS.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.MBS.dto.Mobiles;
import com.cg.MBS.dto.PurchaseDetails;
import com.cg.MBS.exception.Mobile_PurchaseException;
import com.cg.MBS.service.IMobile_PurchaseService;
import com.cg.MBS.service.Mobile_PurchaseImpl;

public class Mobile_PurchaseUI {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub

	int choice = 0;
	IMobile_PurchaseService mobservice = new Mobile_PurchaseImpl();
	
	do{
		printDetail();
		
		Scanner scr = new Scanner(System.in);
		System.out.println("Enter the choice.....");
		choice = scr.nextInt();
		
		switch(choice)
		{
		
		case 1://ADD The mobile product

			System.out.println("Enter the mobile id :");
			int mobId = scr.nextInt();
			System.out.println("Enter mobile name : ");
			String mobName = scr.next();
			System.out.println("Enter the price : ");
			double mobPrice = scr.nextDouble();
			System.out.println("Enter the Quantity : ");
			int mobquantity = scr.nextInt();
			
			Mobiles mob = new Mobiles();
			
			mob.setMobileId(mobId);
			mob.setName(mobName);
			mob.setPrice(mobPrice);
			mob.setQuantity(mobquantity);
			
			try
			{
				mobservice.addMobile(mob);
			}
			catch (Mobile_PurchaseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			break;
			
		case 2:
			
		//	System.out.println("Enter customer name : ");
		//	int PDpuchaseId= scr.nextInt();
			System.out.println("Enter customer name : ");
			String PDcname = scr.next();
			System.out.println("Enter mail ID : ");
			String PDmailId = scr.next();
			System.out.println("Enter phone number");
			long PDphoneno = scr.nextLong();
			System.out.println("Enter mobile Id");
			int PDmobId =  scr.nextInt();
		
			PurchaseDetails PD = new PurchaseDetails();
			
		//	PD.setPurchaseId(PDpuchaseId);
			PD.setCname(PDcname);
			PD.setMailId(PDmailId);
			PD.setPhoneno(PDphoneno);	
			PD.setMobileId(PDmobId);
			
			try {
				mobservice.addPurchaseDetail(PD);
			} catch (Mobile_PurchaseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			break;
		
		case 3:
			
			List<Mobiles> mobData;
			try 
			{
				mobData = mobservice.showallmob();
				
				for (Mobiles mobile : mobData)
			    {
					System.out.println(mobile + "\n");	
			    }
			}
			catch (Mobile_PurchaseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			break;
			
		case 4:
			System.out.println("Enter Mobiule Id");
			mobId = scr.nextInt();
			
			try 
			{
				mobservice.removeMobile(mobId);
			}
			catch
			(Mobile_PurchaseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 
			 System.out.println("employee with" + mobId + "removed succesfully");
			break;
			
		case 5:
			 System.out.println("Enter the lower price");
			 double min = scr.nextDouble();
			 System.out.println("Enter higher price");
			 double max = scr.nextDouble();
			 
			 List<Mobiles> mobrData;
			try
			{
				mobrData = mobservice.SearchMobileRange(min, max);
				
				for (Mobiles mobile : mobrData)
	 			{
	 				System.out.println(mobile + "\n");	
	 			}
			} 
			catch (Mobile_PurchaseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 		
			break;
			
		case 6:
			 System.exit(0);
			break;
		}	
	} while(choice ==6);
	}

	private static void printDetail() 
	{
		// TODO Auto-generated method stub
		
		System.out.println("***********SELECT AN OPTION**********");
		System.out.println("1) ADD NEW MOBILE PHONE");
		System.out.println("2) ADD NEW PURCHASE DEATAILS ");
		System.out.println("3) SHOW ALL MOBILE DEVICES");
		System.out.println("4) REMOVE ANY MOBILE DEVICE");
		System.out.println("5) SEARCH MOBILE BASED ON RANGE");
		System.out.println("6. Exit");
		System.out.println("**************************************");
	}

}
