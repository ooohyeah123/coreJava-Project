package com.cg.MBS.service;

import java.util.List;

import com.cg.MBS.dto.Mobiles;
import com.cg.MBS.dto.PurchaseDetails;
import com.cg.MBS.exception.Mobile_PurchaseException;

public interface IMobile_PurchaseService
{
	public int addMobile(Mobiles mob) throws Mobile_PurchaseException;
	
	public int addPurchaseDetail(PurchaseDetails PD) throws Mobile_PurchaseException;
	
	public List<Mobiles> showallmob() throws Mobile_PurchaseException;
	
	public void removeMobile(int mobId) throws Mobile_PurchaseException;
	
	public List<Mobiles>SearchMobileRange(double high, double low) throws Mobile_PurchaseException;
}
