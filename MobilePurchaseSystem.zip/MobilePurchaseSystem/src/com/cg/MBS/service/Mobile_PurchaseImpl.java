
package com.cg.MBS.service;

import java.util.List;

import com.cg.MBS.DAO.IMobile_PurchaseDao;
import com.cg.MBS.DAO.Mobile_PurchaseDaoImpl;
import com.cg.MBS.dto.Mobiles;
import com.cg.MBS.dto.PurchaseDetails;
import com.cg.MBS.exception.Mobile_PurchaseException;

public class Mobile_PurchaseImpl implements IMobile_PurchaseService
{
 
	IMobile_PurchaseDao mobDao = new Mobile_PurchaseDaoImpl();
	

	@Override
	public int addMobile(Mobiles mob) throws Mobile_PurchaseException {
		
		return mobDao.addMobile(mob);
		
	}

	@Override
	public int addPurchaseDetail(PurchaseDetails PD) throws Mobile_PurchaseException {
		
		return mobDao.addPurchaseDetail(PD);
	}

	@Override
	public List<Mobiles> showallmob() throws Mobile_PurchaseException {
		
		return mobDao.showallmob();
	}

	@Override
	public void removeMobile(int mobId) throws Mobile_PurchaseException {
		// TODO Auto-generated method stub
		 mobDao.removeMobile(mobId);
		
	}

	@Override
	public List<Mobiles> SearchMobileRange(double high, double low) throws Mobile_PurchaseException {
		// TODO Auto-generated method stub
		return mobDao.SearchMobileRange(high, low);
		
	}

}
