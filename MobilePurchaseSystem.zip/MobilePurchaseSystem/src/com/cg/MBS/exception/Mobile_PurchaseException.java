package com.cg.MBS.exception;

public class Mobile_PurchaseException extends Exception
{
	public Mobile_PurchaseException() 
	{
		super();
	}

	public Mobile_PurchaseException(String string) {
		// TODO Auto-generated constructor stub
	}
}
