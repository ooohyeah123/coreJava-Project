package com.cg.MBS.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.MBS.UTIL.DbUtil;
import com.cg.MBS.dto.Mobiles;
import com.cg.MBS.dto.PurchaseDetails;
import com.cg.MBS.exception.Mobile_PurchaseException;


public class Mobile_PurchaseDaoImpl implements IMobile_PurchaseDao{
private static final Logger mylogger=Logger.getLogger(Mobile_PurchaseDaoImpl.class);

		static Connection conn = null;
		static PreparedStatement pstm=null;
	int status=0;


	@Override
	public int addMobile(Mobiles mob) throws Mobile_PurchaseException 
	{
		conn = DbUtil.getConnection();
		String query = "INSERT INTO mobiles VALUES(? , ? , ? , ?)";
		
		   try
		   {
			pstm = conn.prepareStatement(query);
			

			pstm.setInt(1,mob.getMobileId());
			pstm.setString(2, mob.getName());
			pstm.setDouble(3, mob.getPrice());
			pstm.setInt(4, mob.getQuantity());
		
			status = pstm.executeUpdate();
			
			mylogger.info("New Mobile Information added" +status);
		} 
		   catch (SQLException e)
		   {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new Mobile_PurchaseException("Problem In insert");
		}
		   finally
		   {
				  try 
				     {
					  	pstm.close();
					  	conn.close();
					 } 
				  catch (SQLException e) 
				   	 {
					  	e.printStackTrace();
				  	 }
				}
		return status;
		
	}

	@Override
	public int addPurchaseDetail(PurchaseDetails PD) throws Mobile_PurchaseException
	{
		status = 0;
		Connection conn = DbUtil.getConnection();
		PreparedStatement pstm=null;
		
		
		try 
		{
			String queryone = "INSERT INTO purchasedetails VALUES(?,?,?,?,?,?)";
			pstm = conn.prepareStatement(queryone);
			
			int purchaseID = PD.getPurchaseId();
java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());	//WE GET SYSTEM DATE
			
			pstm.setInt ( 1 , purchaseID);
			pstm.setString( 2 , PD.getCname() );
			pstm.setString( 3 , PD.getMailId() );
			pstm.setDate( 4 , date );
			pstm.setLong( 5 , PD.getPhoneno() );
			pstm.setInt( 6 , PD.getMobileId() );
			
			System.out.println(date);
			status = pstm.executeUpdate();
			
			if(status > 0)
				 status = purchaseID ;
	
			mylogger.info("New ProductDetail added");
			
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		throw new Mobile_PurchaseException("Purchase detail cannot be saved..Something went wrong");
		}
		finally
		{
		  try 
		     {
			  	pstm.close();
			  	conn.close();
			  } 
		  catch (SQLException e) 
		   	 {
			  	e.printStackTrace();
		  	 }
		}	
	return status;
	
	}

	@Override
	public List<Mobiles> showallmob() throws Mobile_PurchaseException
	{
		Connection connThree = DbUtil.getConnection();
		PreparedStatement prstm=null;
		String querythree = "SELECT * FROM mobiles";
		List<Mobiles> mobData = new ArrayList<Mobiles>();
		PreparedStatement pstmThree;
		
		try
		{
			pstmThree = connThree.prepareStatement(querythree);
			
			Mobiles mob=null;
			
			ResultSet rs = pstmThree.executeQuery();
			while(rs.next())
			{
				mob= new Mobiles();
				mob.setMobileId(rs.getInt(1));
				mob.setName(rs.getString(2));
				mob.setPrice(rs.getDouble(3));
				mob.setQuantity(rs.getInt(4));
		
				mobData.add(mob);
			}
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return mobData;
	}

	@Override
	public void removeMobile(int mobId) throws Mobile_PurchaseException {
		Connection connFour = DbUtil.getConnection();
		PreparedStatement prstm=null;
		String queryfour = "DELETE FROM mobiles WHERE mobileid=?";
		
		PreparedStatement pstmThree;
		try
		{
			pstmThree = connFour.prepareStatement(queryfour);
			pstmThree.setInt(1, mobId);
			
			int value = pstmThree.executeUpdate();
			if(value == 1)
				mylogger.info("record deleted successfully");
		}
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
	}

	@Override
	public List<Mobiles> SearchMobileRange(double high, double low) throws Mobile_PurchaseException {
		// TODO Auto-generated method stub
		Connection connFive = DbUtil.getConnection();
		PreparedStatement prstm=null;
		String queryfive = "SELECT * FROM mobiles WHERE price > ? AND price < ?";
		
		ArrayList<Mobiles> mobRData=null;
		try {
			PreparedStatement pstmFive=connFive.prepareStatement(queryfive);
			pstmFive.setDouble(1, low);
			pstmFive.setDouble(2, high);
			mobRData = new ArrayList();
			Mobiles mob=null;
		
			ResultSet rsRange = pstmFive.executeQuery();
			while(rsRange.next())
			{
				mob= new Mobiles();
				mob.setMobileId(rsRange.getInt(1));
				mob.setName(rsRange.getString(2));
				mob.setPrice(rsRange.getDouble(3));
				mob.setQuantity(rsRange.getInt(4));
				mobRData.add(mob);
			}
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mobRData;
	}
	
	public static int getPurchaseId() throws Mobile_PurchaseException
	 {

		int id=0;
		try
			{
				conn=DbUtil.getConnection();
				PreparedStatement prstm=null;
				String query = "SELECT prodDetails_seq.nextval FROM DUAL";
				pstm =  conn.prepareStatement(query);
				ResultSet rs = pstm.executeQuery();
				
				if(rs.next())
				{
					id = rs.getInt(1);
					
					mylogger.info("New puchase id is" +id);
				}
			} 
		catch ( SQLException e)
			{
				e.printStackTrace();
				throw new Mobile_PurchaseException("error in getting id");
			}
		finally
		{
	           	try 
	           		{
	           			pstm.close();
	           			conn.close();
	           		} 
	           	catch (SQLException e)
	           		{
	           			e.printStackTrace();
	           		}
				
		}
		return id;
	 }

}
