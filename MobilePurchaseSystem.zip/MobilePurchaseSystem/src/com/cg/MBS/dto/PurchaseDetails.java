package com.cg.MBS.dto;

import oracle.sql.DATE;

public class PurchaseDetails
{
	private int PurchaseId;
	private String Cname;
	private String MailId;
	private long Phoneno;
	private DATE Date;
	private int mobileId;
	
	public PurchaseDetails() {
		super();
		// TODO Auto-generated constructor stub
	}


	public PurchaseDetails(int purchaseId, String cname, String mailId,
			long phoneno, DATE date, int mobileId) {
		super();
		this.PurchaseId = purchaseId;
		this.Cname = cname;
		this.MailId = mailId;
		this.Phoneno = phoneno;
		this.Date = date;
		this.mobileId = mobileId;
	}


	public int getPurchaseId() {
		return PurchaseId;
	}


	public void setPurchaseId(int purchaseId) {
		PurchaseId = purchaseId;
	}


	public String getCname() {
		return Cname;
	}


	public void setCname(String cname) {
		Cname = cname;
	}


	public String getMailId() {
		return MailId;
	}


	public void setMailId(String mailId) {
		MailId = mailId;
	}


	public long getPhoneno() {
		return Phoneno;
	}


	public void setPhoneno(long phoneno) {
		Phoneno = phoneno;
	}


	public DATE getDate() {
		return Date;
	}


	public void setDate(DATE date) {
		Date = date;
	}


	public int getMobileId() {
		return mobileId;
	}


	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}


	@Override
	public String toString() {
		return "PurchaseDetails [PurchaseId=" + PurchaseId + ", Cname=" + Cname
				+ ", MailId=" + MailId + ", Phoneno=" + Phoneno + ", Date="
				+ Date + ", mobileId=" + mobileId + "]";
	}
}
