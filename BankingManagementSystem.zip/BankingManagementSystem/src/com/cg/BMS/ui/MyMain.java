package com.cg.BMS.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.BMS.BankAccService.BankAccDetailsImpl;
import com.cg.BMS.BankAccService.IBankAccDetails;
import com.cg.BMS.Exception.BankAccountDetailsException;
import com.cg.BMS.dto.BankAccountDetails;

public class MyMain {

	private static int AccNum;

	public static void main(String[] args) throws BankAccountDetailsException
	{
		int choice = 0;
		
		int msg = 0;
		String pattern = null;
		
		IBankAccDetails Bankservice = new BankAccDetailsImpl();
		
		do
		{
			printDetail();
			Scanner scr = new Scanner(System.in);
			System.out.println("Enter the choice........");
			choice = scr.nextInt();
			
			switch (choice)
			{
			case 1://**********************ADD***************
				
			//	System.out.println("Enter the Account Number");
			//	long AccNum = scr.nextLong();
				
			pattern = "[A-Z][a-z]{2,10}";//*****************FOR FIRST NAME*************/
				System.out.println("Enter the first name");
				String fName = scr.next();
				try
				{
					Bankservice.validate(fName,pattern);
				} 
				
				catch (BankAccountDetailsException e1)
				{
					e1.printStackTrace();
					System.out.println("First letter should be capital");
					break;
				}
				
			pattern = "[A-Z][a-z]{2,10}";//*****************FOR LAST NAME******/
				System.out.println("Enter the Last Name");
				String lName = scr.next();
				try
				{
					Bankservice.validate(lName,pattern);
				} 
				catch (BankAccountDetailsException e1) 
				{
					e1.printStackTrace();
					System.out.println("First Letter should be capital");
				}
			
			pattern = "[a-z]+.[a-z]+@capgemini.com";//*************FOR MAILID***/
				System.out.println("Enter the mailId");
				String mailId = scr.next();
				try 
				{
					Bankservice.validate(mailId, pattern);
				} 
				catch (BankAccountDetailsException e1) 
				{
					e1.printStackTrace();
					System.out.println("Mail id should be valid");
					break;
				}
				
			pattern= "[0-9]{10}";//****************************PHONE NUMBER*****//
				System.out.println("Enter the Phone Number");
				long phnNum = scr.nextLong();
				String phoneno= Long.toString(phnNum);
				Bankservice.validate(phoneno, pattern);
			
				System.out.println("Please mention your Gender");//****GENDER****//
				String Gender = scr.next();
				
				
			
			pattern = "[15-99]{2}";//***************************FOR AGE*********//
				System.out.println("please mention your Age");
				int Age = scr.nextInt();
				String age=Integer.toString(Age);
				Bankservice.validate(age, pattern);
				
				
				BankAccountDetails Bank = new BankAccountDetails();
		//		Bank.setAccNum(AccNum);
				Bank.setfName(fName);
				Bank.setlName(lName);
				Bank.setMailId(mailId);
				Bank.setPhnNum(phnNum);
				Bank.setGender(Gender);
				Bank.setAge(Age);
				
				try 
				{
					Bankservice.addBankAccountDetails(Bank);
				} 
				
				catch (BankAccountDetailsException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
					break;
				}
			
				break;
				
			case 2:	//*******************SHow All*********************
				
				List<BankAccountDetails> myBank = null;
				
				try
				{
					myBank = Bankservice.showAll();
				}
				
				catch (BankAccountDetailsException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				
				}
				
				for(BankAccountDetails Details : myBank)
				{
					System.out.println("AccNum is" +Details.getAccNum());
					System.out.println("First Name is " +Details.getfName());
					System.out.println("Last Name is " +Details.getlName());
					System.out.println("MailId is " +Details.getMailId());
					System.out.println("Phone Number is"+Details.getPhnNum());
					System.out.println("Gender" +Details.getGender());
					System.out.println("Age" +Details.getAge());
				}
				break;
				
			case 3:
				System.out.println("Enter the Account Number");
					int id = scr.nextInt();
					BankAccountDetails GetDetails = null;
						
					GetDetails = Bankservice.searchBankAccountDetails(id);
				
				System.out.println("Account Num" +GetDetails.getAccNum());
				System.out.println("First Name" +GetDetails.getfName());
				System.out.println("Last Name is " +GetDetails.getlName());
				System.out.println("MailId is " +GetDetails.getMailId());
				System.out.println("Phone Number is"+GetDetails.getPhnNum());
				System.out.println("Gender" +GetDetails.getGender());
				System.out.println("Age" +GetDetails.getAge());
				break;
			
			case 4://**********************UPDATE**************************// 
				break;
				
			case 5:
				System.out.println("Enter the Account Number");
				AccNum = scr.nextInt();
				
				Bankservice.removeBankAccountDetails(AccNum);
				
				System.out.println("Account Number with " + AccNum + "Successfully Removed");
				
				break;
			
			case 6:
				System.exit(0);
				break;
			}
			
		}while(choice != 6);
	}

	private static void printDetail()
	{
		System.out.println("***********************************");
		System.out.println("       1) ADD THE DETAILS          ");
		System.out.println("       2) Show All Accounts        ");
		System.out.println("       3).Get Accounts details     ");
		System.out.println("       4).UPDATE THE Account       ");
		System.out.println("       5).REMOVE THE Account       ");
		System.out.println("       6).EXIT                     ");
		System.out.println("***********************************");
		
	}

}
