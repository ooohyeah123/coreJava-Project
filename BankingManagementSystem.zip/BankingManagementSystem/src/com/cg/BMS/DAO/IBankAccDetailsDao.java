package com.cg.BMS.DAO;

import java.util.List;

import com.cg.BMS.Exception.BankAccountDetailsException;
import com.cg.BMS.dto.BankAccountDetails;

public interface IBankAccDetailsDao
{
	public int addBankAccountDetails(BankAccountDetails bank) throws BankAccountDetailsException;
	
	public List<BankAccountDetails> showAll() throws BankAccountDetailsException;

	BankAccountDetails searchBankAccountDetails(int id) throws BankAccountDetailsException;
	
	public void removeBankAccountDetails(int AccNum);
}
