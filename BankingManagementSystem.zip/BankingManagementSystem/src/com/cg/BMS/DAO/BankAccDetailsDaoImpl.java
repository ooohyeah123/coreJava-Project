package com.cg.BMS.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.BMS.Exception.BankAccountDetailsException;
import com.cg.BMS.UTIL.DbUtil;
import com.cg.BMS.dto.BankAccountDetails;


public class BankAccDetailsDaoImpl implements IBankAccDetailsDao
{

	public static final Logger myLogger=Logger.getLogger(BankAccDetailsDaoImpl.class);
	
	static Connection conn = null;
	static PreparedStatement pstm = null;
	int status=0;
	
	@Override
	public int addBankAccountDetails(BankAccountDetails Bank) throws BankAccountDetailsException {
		
		int status=0;
		int AccNumReturn=0;
	
		 
		 try
		 {
				
			 conn = DbUtil.getConnection();
			 
			 int AccNumber = getAccNum();
			 
			 String querry = " INSERT INTO BankAccountDetails Values(?,?,?,?,?,?,?)";
			 
			pstm = conn.prepareStatement(querry);
			
			 pstm.setLong(1, AccNumber);
			 pstm.setString(2,Bank.getfName());
			 pstm.setString(3,Bank.getlName());
			 pstm.setString(4,Bank.getMailId());
			 pstm.setLong(5,Bank.getPhnNum());
			 pstm.setString(6,Bank.getGender());
			 pstm.setInt(7,Bank.getAge());
			 
			 status=pstm.executeUpdate();
			 if(status == 1)
			 {
				AccNumReturn = AccNumber;
				
				System.out.println("Wlecome to Manku Bank Your Account num is" +AccNumber);
				
				myLogger.info("Data Inserted...." +AccNumber);
			 }
		}
		 
		 catch (SQLException e)
		 {
			 myLogger.info("Data is not Inserted....");
			e.printStackTrace();
			throw new BankAccountDetailsException("Problem in inserting the data");
		}
		 
		 finally
		 {
			 try 
		     {
			  	pstm.close();
			  	conn.close();
			 } 
		  catch (SQLException e) 
		   	 {
			  myLogger.fatal("Unable to close connection");
			  	e.printStackTrace();
		  	 }
		 }
		 
		return AccNumReturn;
	}

	@Override
	public List<BankAccountDetails> showAll() throws BankAccountDetailsException
	{
		List<BankAccountDetails>myList = new ArrayList<BankAccountDetails>();
		
		Connection conn = DbUtil.getConnection();
		
		String querrytwo = "SELECT AccNum,fName,lName,MailId,PhnNum,Gender,Age FROM BankAccountDetails";
		
		try
		{
			pstm = conn.prepareStatement(querrytwo);
			ResultSet res = pstm.executeQuery();
			
			while(res.next())
			{
				BankAccountDetails bad = new BankAccountDetails();
				
				bad.setAccNum(res.getInt("AccNum"));
				bad.setfName(res.getString("fName"));
				bad.setlName(res.getString("lName"));
				bad.setMailId(res.getString("MailId"));
				bad.setPhnNum(res.getLong("PhnNum"));
				bad.setGender(res.getString("Gender"));
				bad.setAge(res.getInt("Age"));
				
				myList.add(bad);
			}
			
			myLogger.info("Data Displayed.............");
		}
		
		catch (SQLException e)
		{
			myLogger.info("Showall is not working.........");
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			throw new BankAccountDetailsException("Problem in ShowAll..........");
			
		}
		
		 finally
		 {
			 try 
		     {
			  	pstm.close();
			  	conn.close();
			 } 
		  catch (SQLException e) 
		   	 {
			  myLogger.fatal("Unable to close connection");
			  	e.printStackTrace();
		  	 }
		 }
		
		return myList;
	}
	
	@Override
	public BankAccountDetails searchBankAccountDetails(int id) throws BankAccountDetailsException  {
		BankAccountDetails Banksearch = null;
		
		try 
		{
			conn=DbUtil.getConnection();
			String querrythree = "SELECT AccNum,fName,lName,MailId,PhnNum,Gender,"
					+ "Age FROM BankAccountDetails WHERE AccNum=?";
			
			pstm = conn.prepareStatement(querrythree);
			pstm.setInt(1, id);
			
			ResultSet resthree = pstm.executeQuery();
			while(resthree.next())
			{
				Banksearch = new BankAccountDetails();
					Banksearch.setAccNum(resthree.getInt("AccNum"));
					Banksearch.setfName(resthree.getString("fName"));
					Banksearch.setlName(resthree.getString("lName"));
					Banksearch.setMailId(resthree.getString("MailId"));
					Banksearch.setPhnNum(resthree.getLong("PhnNum"));
					Banksearch.setGender(resthree.getString("Gender"));
					Banksearch.setAge(resthree.getInt("Age"));
			}
			
			myLogger.info("Get The Employee Details...................");
		}
		
		catch (BankAccountDetailsException | SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BankAccountDetailsException("problem in Retriving the Data");
		}
		
		 finally
		 {
			 try 
		     {
			  	pstm.close();
			  	conn.close();
			 } 
		  catch (SQLException e) 
		   	 {
			  myLogger.fatal("Unable to close connection");
			  	e.printStackTrace();
		  	 }
		 }
		return Banksearch;
	}
	
	@Override
	public void removeBankAccountDetails(int AccNum ) {
		BankAccountDetails AccRemove = null;
		
		try
		{
			conn = DbUtil.getConnection();
			String querryFour = "DELETE FROM BankAccountDetails WHERE AccNum=?";
			
			pstm = conn.prepareStatement(querryFour);
			pstm.setInt(1, AccNum);
			
			int value=pstm.executeUpdate();
			if(value==1){
			System.out.println("dATA dELETED sUCCEFULLY");	
			
			myLogger.info("Data Deleted Successfully......................");
			}
		} 
		
		catch (BankAccountDetailsException | SQLException e)
		{
			 myLogger.info("Problem Is Encoutered while removing data......");
			e.printStackTrace();
			System.out.println("Problem in removing........");
		}
		 finally
		 {
			 try 
		     {
			  	pstm.close();
			  	conn.close();
			 } 
		  catch (SQLException e) 
		   	 {
			  myLogger.fatal("Unable to close connection");
			  	e.printStackTrace();
		  	 }
		 }
		
		
	}

	
	private static int getAccNum() throws BankAccountDetailsException
	{
		int AccNum1 = 0;
		
		try
		{
			Connection connthree = DbUtil.getConnection();
			PreparedStatement pstmthree=null;
			String query = "SELECT AccNumber.nextval FROM DUAL";
			pstmthree =  connthree.prepareStatement(query);
			ResultSet rstwo = pstmthree.executeQuery();
			
			while(rstwo.next())
			{
				AccNum1=rstwo.getInt(1);
			}
			
			myLogger.info("AccNum generated.................");
		} 
		
		catch (SQLException e)
		{
			 myLogger.info("aAccount number couldnot be generated");
			e.printStackTrace();
			throw new BankAccountDetailsException("Problem in gettting the AccNum");
			
		}
		
		return AccNum1;
		
	}



	
}

