package com.cg.BMS.JUnit;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.BMS.DAO.BankAccDetailsDaoImpl;
import com.cg.BMS.Exception.BankAccountDetailsException;
import com.cg.BMS.dto.BankAccountDetails;

public class BankAccountDetailsTestCase {

	BankAccDetailsDaoImpl BDao = null;
	
	BankAccountDetails BAD = null;
	
	@Before
	public void beforeTest()
	{
		BAD = new BankAccountDetails();
		BAD.setfName("aaaa");
		BAD.setlName("bbbb");
		BAD.setMailId("aa.bb@capgemini.com");
		BAD.setPhnNum(56666666);
		BAD.setGender("female");
		BAD.setAge(60);
		
		BDao = new BankAccDetailsDaoImpl();
		
	}
	
	@Test
	public void Firsttest() throws BankAccountDetailsException{
		
		assertEquals(121413,BDao.addBankAccountDetails(BAD));
	}
	
	@Test
	public void Secondtest() throws BankAccountDetailsException{
		
		List<BankAccountDetails> BAD = new ArrayList<BankAccountDetails>();
		
		assertEquals("aaaa",BDao.searchBankAccountDetails(121413));
	}
	

	@After
	public void afterTest()
	{
		BDao = null;
	}
	
}
