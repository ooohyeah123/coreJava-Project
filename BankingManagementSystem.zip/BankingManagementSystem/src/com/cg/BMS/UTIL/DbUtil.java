package com.cg.BMS.UTIL;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.cg.BMS.Exception.BankAccountDetailsException;

public class DbUtil
{
	static Connection conn = null;
	
	private static final Logger myLogger = Logger.getLogger(DbUtil.class);
	
	public static Connection getConnection() throws BankAccountDetailsException
	{
		FileInputStream fileRead;
		
		try
		{
			fileRead = new FileInputStream("oracle.properties");
			
			Properties pros = new Properties();
			pros.load(fileRead);
			
			String driver = pros.getProperty("oracle.driver");
			String url = pros.getProperty("oracle.url");
			String uname = pros.getProperty("oracle.username");
			String upass = pros.getProperty("oracle.password");
			
			Class.forName(driver);
			conn = DriverManager.getConnection(url,uname,upass);
			myLogger.info("Connection established..........");
		}
		
		catch (ClassNotFoundException | IOException | SQLException e)
		{
			myLogger.info("Connection not Established..........."+e.getMessage());
			e.printStackTrace();
			throw new BankAccountDetailsException("No Connection Established........");
		}
		return conn;
	}
}
