package com.cg.BMS.dto;

public class BankAccountDetails 
{	
	private int AccNum;
	private String fName;
	private String lName;
	private String mailId;
	private long phnNum;
	private String Gender;
	private int Age;
	
	public BankAccountDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BankAccountDetails(int accNum, String fName, String lName,
			String mailId, long phnNum, String gender, int age) {
		super();
		AccNum = accNum;
		this.fName = fName;
		this.lName = lName;
		this.mailId = mailId;
		this.phnNum = phnNum;
		this.Gender = gender;
		this.Age = age;
	}

	public int getAccNum() {
		return AccNum;
	}

	public void setAccNum(int accNum) {
		AccNum = accNum;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public long getPhnNum() {
		return phnNum;
	}

	public void setPhnNum(long phnNum) {
		this.phnNum = phnNum;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public int getAge() {
		return Age;
	}

	public void setAge(int age) {
		Age = age;
	}

	}	

