package com.cg.BMS.BankAccService;

import java.util.List;

import com.cg.BMS.Exception.BankAccountDetailsException;
import com.cg.BMS.dto.BankAccountDetails;

public interface IBankAccDetails 
{

	public int addBankAccountDetails(BankAccountDetails bank) throws BankAccountDetailsException;

	public List<BankAccountDetails> showAll() throws BankAccountDetailsException;
	
	public boolean validate(String fName, String pattern) throws BankAccountDetailsException;

	public BankAccountDetails searchBankAccountDetails(int id) throws BankAccountDetailsException;

	public void removeBankAccountDetails(int AccNum);

//	public BankAccountDetails updateBankAccountDetails(int id);


	
}

