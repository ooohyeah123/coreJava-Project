package com.cg.BMS.BankAccService;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.BMS.DAO.BankAccDetailsDaoImpl;
import com.cg.BMS.DAO.IBankAccDetailsDao;
import com.cg.BMS.Exception.BankAccountDetailsException;
import com.cg.BMS.dto.BankAccountDetails;

public class BankAccDetailsImpl implements IBankAccDetails
{
	
	IBankAccDetailsDao BankDao = new BankAccDetailsDaoImpl();

	@Override
	public int addBankAccountDetails(BankAccountDetails Bank) throws BankAccountDetailsException {
		// TODO Auto-generated method stub
		return BankDao.addBankAccountDetails(Bank);
	}

	@Override
	public List<BankAccountDetails> showAll() throws BankAccountDetailsException {
		// TODO Auto-generated method stub
		return BankDao.showAll();
	}
	
	@Override
	public boolean validate(String fName, String pattern) throws BankAccountDetailsException {
		
		boolean validation=Pattern.matches(pattern, fName);
		if(!validation){
			throw new BankAccountDetailsException("Doesnot met the required pattern");
		}
		return validation;
		
	}


	@Override
	public BankAccountDetails searchBankAccountDetails(int id) throws BankAccountDetailsException {
		
		return BankDao.searchBankAccountDetails(id);
	}

	@Override
	public void removeBankAccountDetails(int AccNum) {
		
		
	}

}
 