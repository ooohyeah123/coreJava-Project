package com.cg.BMS.Exception;

public class BankAccountDetailsException extends Exception
{

	public BankAccountDetailsException(String string) {
		// TODO Auto-generated constructor stub
	}
	
}
